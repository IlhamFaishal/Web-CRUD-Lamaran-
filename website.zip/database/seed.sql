-- Seed Data for POS Besi & Kayu

-- Users (admin / admin123)
-- Hash generated using PASSWORD_BCRYPT
INSERT INTO `users` (`username`, `password`, `role`) VALUES
('admin', '$2y$10$b1tulQfnJtGocZFczeQhKyjV0Z7XEbaLOF.WbE9z', 'admin');


